function StudentDetails(props){
    return(
        <div>
            <h1>TASK-2</h1>
            <h2>Student Information</h2>
            <p><strong><span>Student Name:</span></strong>{props.sname}</p>
            <p><strong><span>Course Name:</span></strong>{props.scourse}</p>
            <p><strong><span>College Name:</span></strong>{props.scollege}</p>
        </div>
    )

}
export default StudentDetails