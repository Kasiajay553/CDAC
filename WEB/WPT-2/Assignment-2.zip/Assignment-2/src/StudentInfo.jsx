import StudentDetails from "./StudentDetails"

function StudentInfo( {sname,scourse,scollege}){
    return(
        <>        
        <hr></hr>
        <StudentDetails sname={sname} scourse={scourse} scollege={scollege} />
        </>

    )
}
export default StudentInfo