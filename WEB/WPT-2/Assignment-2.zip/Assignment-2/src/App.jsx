import { useState } from 'react'
import './App.css'
import Student from './Student'
import StudentInfo from './StudentInfo'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <Student sname={"CDAC"} scourse={"React JS"} scollege={"ABC College"}/>
      <Student  sname={"Ravi"} scourse={"React JS"} scollege={"ABC College"}/>
      <Student  sname={"Sita"} scourse={"React JS"} scollege={"ABC College"}/>
     <StudentInfo sname={"CDAC"} scourse={"React JS"} scollege={"ABC College"}></StudentInfo>
    </>
  )
}

export default App
