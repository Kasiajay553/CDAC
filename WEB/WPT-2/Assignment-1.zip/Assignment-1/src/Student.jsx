function Student(){
    return(
         <div>
            <h1>TASK-1</h1>
            <p><strong><span >Student Name:</span></strong> CDAC</p>
            <p><strong><span >Course Name:</span></strong> React JS</p>
            <p><strong><span >College Name:</span></strong> ABC College</p>
        </div>
    )
}
export default Student