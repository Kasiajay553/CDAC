function InterestCalculator(){
    let principalAmount=10000;
    let rateOfInterest=5;
    let timePeriod=2;
    let totalamount=(principalAmount*rateOfInterest*timePeriod)/100;
    return(
        <>
        <hr/>
        <h1>
            TASK-2
        </h1>
       <h2>Simple Interest Calculator</h2>
       <p><strong><span>Principal Amount : </span></strong>{principalAmount}</p>
       <p><strong><span>Rate of Interest : </span></strong>{rateOfInterest}%</p>
       <p><strong><span>Time Period : </span></strong>{timePeriod} years</p>
       <p><strong><span>Simple Interes : </span></strong>{totalamount}</p>
        </>
    )
}
export default InterestCalculator