import React from 'react'

function StudentResult(props) {
    let name = props.name;
    let marks = props.marks;
    if (marks > 35) {

        return (
            <div>
                <h2>TASK-1</h2>
                <p><strong><span>Student Name: </span></strong>{name}</p>
                <p><strong><span>Marks Obtained:</span></strong>{marks}</p>
                <p><strong><span>Result: </span></strong>PASS</p>
            </div>
        )
    } else {
        return (
            <div>
                <h2>TASK-1</h2>
                <p><strong><span>Student Name: </span></strong>{name}</p>
                <p><strong><span>Marks Obtained: </span></strong>{marks}</p>
                <p><strong><span>Result: </span></strong>FAIL</p>
            </div>
        )
    }
}


export default StudentResult