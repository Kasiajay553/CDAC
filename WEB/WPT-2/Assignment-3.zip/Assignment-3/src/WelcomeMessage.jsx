import React, { useState } from 'react';

function WelcomeMessage() {
  const [message, setMessage] = useState(false);
   const [hello, sethello] = useState(false);

  function Welcome() {
    setMessage(!message);
  }
  function SayHello(){
    sethello(!hello);
  }

  return (
    <>
      <h1>TASK-2</h1>

      <button onClick={Welcome}>Click ME</button>

      {message && <h2>Welcome to React JS!</h2>}
      <button onClick={SayHello}>Say Hello</button>
      {
        hello?
            (<h2>Hello, Students!</h2>):null
      }
    </>
  );
}

export default WelcomeMessage;
