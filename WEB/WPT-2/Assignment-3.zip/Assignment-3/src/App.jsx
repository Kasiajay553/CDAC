

import './App.css'
import StudentResult from './StudentResult'

function App() {


  return (
    <>
      <StudentResult  name={"CDAC"} marks={75}/>
      <hr></hr>
      <StudentResult  name={"CDAC"} marks={25}/>
    </>
  )
}

export default App
