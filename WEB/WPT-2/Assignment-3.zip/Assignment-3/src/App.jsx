

import './App.css'
import StudentResult from './StudentResult'
import WelcomeMessage from './WelcomeMessage'

function App() {


  return (
    <>
      <StudentResult  name={"CDAC"} marks={75}/>
      <hr></hr>
      <StudentResult  name={"CDAC"} marks={25}/>
      <hr></hr>
      <WelcomeMessage/>
    </>
  )
}

export default App
