import React from 'react'

function Courses() {
  return (
    <div style={{height:'50px', backgroundColor:'pink', justifyItems:'center'}}><h1>We offer BCA, BBA and BSc courses</h1></div>
  )
}

export default Courses