import React from 'react'

function Admissions() {
  return (
    <div  style={{height:'50px', backgroundColor:'pink', justifyItems:'center'}}><h1>Admissions are now open</h1></div>
  )
}

export default Admissions