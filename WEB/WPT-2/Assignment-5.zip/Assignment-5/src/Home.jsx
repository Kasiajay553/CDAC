import React from 'react'

function Home() {
  return (
    <div style={{height:'50px', backgroundColor:'pink', justifyItems:'center'}}><h1>Welcome to ABC College</h1></div>
  )
}

export default Home