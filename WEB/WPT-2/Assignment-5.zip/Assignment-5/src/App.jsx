import {BrowserRouter,Routes,Route,Link} from 'react-router'
import './App.css'
import StudentList from './StudentList'
import Home from './Home'
import Courses from './Courses'
import Admissions from './Admissions'


function App() {
  return (
    <>
    <BrowserRouter>
      <nav>
      <Link className="link" to={'/Home'}>HOME</Link>
      <span className='Separator'>|</span>
      <Link class="link" to={'/Courses'}>Courses</Link>
      <span className='Separator'>|</span>
      <Link className="link" to={'/Admissions'}>Admissions</Link>
      </nav>
      <Routes>
        <Route path='/Home'element={<Home></Home>}></Route>
        <Route path='/Courses'element={<Courses/>}></Route>
        <Route path='/Admissions'element={<Admissions/>}></Route>
      </Routes>
      </BrowserRouter>
      <StudentList/>
     
      
    
    </>
  )
}

export default App
