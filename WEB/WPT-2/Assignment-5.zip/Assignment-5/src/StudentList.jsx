import React from 'react'

function StudentList() {
    
        let studentNames=["Ravi","Sita","Ramesh","Priya","Kiran"]
    
  return (
    <>
     <hr></hr>
    <h1>TASK-1</h1>
    <div>StudentList</div>
    <ul>
        {studentNames.map((name)=>{
          return <li key={name}>{name}</li>

        })}
    </ul>
   
    </>
  )
}

export default StudentList