
import React,{useState,useEffect} from "react"

function Welcome() {
    let [showMessage,setMessage]=useState(false)
    function namedWelcome(){
        setMessage(!showMessage)   
        
    }
    useEffect(()=>{
        console.log("Welcome component mounted")
    },[])

  return (
    <>
    <h2>TASK-2</h2>
    <button onClick={namedWelcome}> click to see meassage</button>
    {showMessage && <h3>Welcome to react js !</h3>}
    </> 
  )
}

export default Welcome  