import React, { useState } from 'react';

function PasswordToggle() {
    let [isPasswordVisible, setIsPasswordVisible] = useState(false)


    const togglePasswordVisibility = () => {
        setIsPasswordVisible(!isPasswordVisible);
    };
    function showpassword() {
        setIsPasswordVisible(true)
    }
    function hidepassword() {
        setIsPasswordVisible(false)
    }
    return (
        <div>
            <h2>TASK-1 </h2>
            <h3>Password Toggle Component</h3>

            <div >

                <input type={isPasswordVisible ? 'text' : 'password'}
                    placeholder="Enter your password" />

                <button onClick={togglePasswordVisibility}>
                    {isPasswordVisible ? 'Hide Password' : 'Show Password'}
                </button>

            </div>

            <input type={isPasswordVisible ? "text" : "password"} placeholder='enter your password' />
            <button onClick={isPasswordVisible ? hidepassword : showpassword}>{isPasswordVisible ? 'Hide Password' : 'Show Password'}</button>
            <br></br>

            <input type={isPasswordVisible ? "text" : "password"} placeholder='enter your password' />
            <button onClick={showpassword}>Show Password</button>
            <button onClick={hidepassword}>Hidden Password</button>
            <hr></hr>
        </div>
    );



}

export default PasswordToggle;
