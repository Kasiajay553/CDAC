
import './App.css'
import PasswordToggle from './PasswordToggle'
import Welcome from './Welcome'

function App() {
  

  return (
    <>
      
        <PasswordToggle/>
        <Welcome/>
    </>
  )
}

export default App
