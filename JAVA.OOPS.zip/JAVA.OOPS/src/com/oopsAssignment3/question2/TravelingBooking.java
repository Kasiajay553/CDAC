package com.oopsAssignment3.question2;

public class TravelingBooking {
	int bookingId;
	int passengerName;
	String source;
	String destination;
	int distance;
	TravelingBooking(int bookingId,	int passengerName,	String source,String destination,int distance){
		this.bookingId= bookingId;
		this.passengerName= passengerName;
		this.source= source;
		this.destination= destination;
		this.distance= distance;
	}
	
	void calculateFare() {
		System.out.println("the super class method");
	}
	void displaydertails() {
		System.out.println("the booking Id is : "+bookingId);
		System.out.println("the passenger name is : "+passengerName);
		System.out.println("the source place  is : "+source);
		System.out.println("the destination place is : "+destination);
		System.out.println("the distance to travel is : "+distance);
	}
}
