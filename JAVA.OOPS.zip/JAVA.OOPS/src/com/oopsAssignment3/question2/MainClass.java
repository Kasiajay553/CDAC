package com.oopsAssignment3.question2;
import java.util.Scanner;


public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("the booking Id is : ");
		int bookingId=sc.nextInt();
		sc.nextLine();
		System.out.println("the passenger name is : ");
		String passengerName=sc.next();
		System.out.println("the source place  is : ");
		String source=sc.next();
		System.out.println("the destination place is : ");
		String destination=sc.next();
		System.out.println("the distance to travel is : ");
		int distance=sc.nextInt();
		

	}

}
