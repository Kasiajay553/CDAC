package com.oopsAssignment3.question2;

public class TrainBooking extends TravelingBooking {
	int trainNumber;
	String coachType;
	TrainBooking(int bookingId,int passengerName,String source,String destination,int distance,int trainNumber,String coachType){
		super(bookingId,passengerName, source,destination,distance);
		this.trainNumber=trainNumber;
		this.coachType=coachType;
		
	}
	@Override
	void calculateFare() {
		if(coachType.equalsIgnoreCase("AC")) {
			displaydertails();
			System.out.println("the Train number is : "+trainNumber);
			System.out.println("the Fare of AC Train is : "+(distance*12));
		}
		else if(coachType.equalsIgnoreCase("non Ac")){
			displaydertails();
			System.out.println("the Train number is : "+trainNumber);
			System.out.println("the Fare of AC train is : "+(distance*10));
		}
		
	}

}
