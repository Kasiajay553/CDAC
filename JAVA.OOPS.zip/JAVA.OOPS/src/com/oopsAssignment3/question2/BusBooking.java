package com.oopsAssignment3.question2;

public class BusBooking extends TravelingBooking {
	String bustype;
	int seatno;
	BusBooking(int bookingId,int passengerName,String source,String destination,int distance,String bustype,int seatno){
		super(bookingId,passengerName, source,destination,distance);
		this.bustype=bustype;
		this.seatno=seatno;
		
	}
    @Override  
	void calculateFare() {
		if(bustype.equalsIgnoreCase("AC")) {
			displaydertails();
			System.out.println("the seat no is : "+seatno);
			System.out.println("the Fare of AC bus is : "+(distance*15));
		}
		else if(bustype.equalsIgnoreCase("non Ac")){
			displaydertails();
			System.out.println("the seat no is : "+seatno);
			System.out.println("the Fare of AC bus is : "+(distance*11));
		}
		
	}

}
