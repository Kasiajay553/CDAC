package com.java.pratice;
import java.util.Scanner;

public class Overloading {
	
	static void nikhil(int a, int b) {
		System.out.println((a+b));
	}
	static void nikhil(int a, int b,int c) {
		System.out.println((a+b+c));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		int a= sc.nextInt();
		int b= sc.nextInt();
		int c=sc.nextInt();
//		Overloading n= new Overloading();
//		n.nikhil(a, b);
		Overloading.nikhil(a, b);
		Overloading.nikhil(a, b, c);
	}

}
