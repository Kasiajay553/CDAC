package com.java.pratice;

public class Nikhil {
	void display() {
		System.out.println("give the input ");
	}

}
