package com.java.pratice;

public class Overriding {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Nikhilll n=new Nikhilll();
		n.display();
	}

}
