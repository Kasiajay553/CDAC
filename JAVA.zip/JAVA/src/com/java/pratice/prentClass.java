package com.java.pratice;

public class prentClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pratice p=new Pratice(23);
		p.method();
		
	}

}
