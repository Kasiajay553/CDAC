package com.java.pratice;
import java.util.ArrayList;

public class ArraylistPratice {

	public static void main(String[] args) {
	ArrayList<Integer> arr=new ArrayList<>();

	}

}
