package com.java.pratice;

public class Pratice {
 static int a;
 Pratice(int a){
	this.a=a;
}
void method() {
	System.out.println(a);
}
}
