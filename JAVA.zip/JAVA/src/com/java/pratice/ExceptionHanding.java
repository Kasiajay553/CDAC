package com.java.pratice;

public class ExceptionHanding {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		int a=20;
		int b=0;
		if(b==0) {
			throw new ArithmeticException("we caqn divis");
		}

	}

}
