package com.java.pratice;

public class Nikhilll extends Nikhil {
	void display() {
		System.out.println("will quite the course");
	}

}
