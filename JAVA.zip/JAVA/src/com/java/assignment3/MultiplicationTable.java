package com.java.assignment3;
import java.util.Scanner;
public class MultiplicationTable {
	static int muilple(int num,int i) {
		return num*i;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);		
		System.out.println("Enter the number :");
		int num=sc.nextInt();

		for(int i=1;i<=10;i++) {
			System.out.println(num +"*"+i+"="+muilple(num,i));
		}

	}

}
