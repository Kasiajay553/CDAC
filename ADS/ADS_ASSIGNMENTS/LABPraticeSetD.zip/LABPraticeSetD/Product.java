package com.LABPraticeSetD;

/**
 * Product model class representing individual e-commerce items.
 */
class Product {
    private int id;
    private String name;
    private String category;
    private double rating; // 1.0 to 5.0 stars
    private double price;

    public Product(int id, String name, String category, double rating, double price) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.rating = rating;
        this.price = price;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public double getRating() { return rating; }
    public double getPrice() { return price; }

    @Override
    public String toString() {
        return String.format("Product [ID=%d, Name=\"%-16s\", Cat=%-11s, Rating=%.1f*, Price Rs. %,.2f]",
                id, name, category, rating, price);
    }
}
