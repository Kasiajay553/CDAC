package com.LABPraticeSetD;

/**
 * Custom Binary Search Tree (BST) storing product records ordered by their unique ID.
 */
public class ProductBST {

    private static class BSTNode {
        Product data;
        BSTNode left, right;

        BSTNode(Product data) {
            this.data = data;
            this.left = this.right = null;
        }
    }

    private BSTNode root;

    public ProductBST() {
        this.root = null;
    }

    /**
     * 1. Public method to insert a new Product into the BST ordered by ID.
     */
    public void insert(Product prod) {
        root=insertRec(root,prod);
    }

    private BSTNode insertRec(BSTNode curr, Product prod) {
    	if(curr==null) {
    		return new BSTNode(prod);
    	}
    	if(prod.getId()<curr.data.getId()) {
    		curr.left=insertRec(curr.left,prod);
    	}
    	else if(prod.getId()>curr.data.getId()) {
    		curr.right=insertRec(curr.right,prod);
    	}
    	
		
		return curr;
	}

	/**
     * Helper method for recursive BST insertion based on product ID.
     */
    
    

    /**
     * 2. Inorder Traversal: Left -> Root -> Right (Displays products sorted in ascending order of ID).
     */
    public void inorder() {
        inoderRec(root);
    }

    

    private void inoderRec(BSTNode curr) {
		if(curr!=null) {
			inoderRec(curr.left);
			System.out.println(curr.data);
			inoderRec(curr.right);
		}
		
	}

	/**
     * 3. Preorder Traversal: Root -> Left -> Right.
     */
    public void preorder() {
       preorderRec(root);
    }

   

    private void preorderRec(BSTNode curr) {
    	if(curr!=null) {
    		System.out.println(curr.data);
    		preorderRec(curr.left);
			preorderRec(curr.right);
			
		}
	}

	/**
     * 4. Recursively computes and returns the maximum height (depth) of the BST.
     * Returns 0 for an empty tree.
     */
    public int height() {
        return heightRec(root);
    }

    

    private int heightRec(BSTNode curr) {
    	if(curr == null) {
    		return 0;
    	}
    	int height=0;
    	int leftheight=heightRec(curr.left);
    	int rightheight=heightRec(curr.right);
    	height=Math.max(leftheight,rightheight)+1;
		return height;
	}

	// DRIVER PROGRAM
    public static void main(String[] args) {
        ProductBST bst = new ProductBST();

        bst.insert(new Product(50, "Smartphone", "Mobiles", 4.6, 25000.0));
        bst.insert(new Product(25, "Tablet", "Electronics", 4.3, 18000.0));
        bst.insert(new Product(75, "Ultrabook", "Computers", 4.8, 65000.0));
        bst.insert(new Product(10, "Stylus Pen", "Accessories", 4.1, 1500.0));
        bst.insert(new Product(35, "Tablet Case", "Accessories", 4.0, 799.0));
        bst.insert(new Product(60, "Wireless Router", "Networking", 4.4, 3200.0));
        bst.insert(new Product(90, "Gaming Chair", "Furniture", 4.7, 14000.0));

        System.out.println("--- 1. INORDER TRAVERSAL (Sorted by ID) ---");
        bst.inorder();

        System.out.println("\n--- 2. PREORDER TRAVERSAL (Root -> Left -> Right) ---");
        bst.preorder();

        System.out.println("\n--- 3. TREE HEIGHT ---");
        System.out.println("Calculated Tree Height: " + bst.height());
    }
}
