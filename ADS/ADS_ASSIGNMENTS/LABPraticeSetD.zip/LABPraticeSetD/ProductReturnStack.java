package com.LABPraticeSetD;

/**
 * Custom Stack (LIFO) implemented using a Singly Linked List to track returned e-commerce packages.
 */
public class ProductReturnStack {

    private static class Node {
        Product data;
        Node next;

        Node(Product data) {
            this.data = data;
            this.next = null;
        }
    }

    private Node top;
    private int size;

    public ProductReturnStack() {
        this.top = null;
        this.size = 0;
    }

    /**
     * 1. Pushes a returned product onto the top of the stack.
     */
    public void push(Product prod) {
       Node newnode=new Node(prod);
       newnode.next=top;
       top=newnode;
       size++;
    }

    /**
     * 2. Removes and returns the top product from the stack.
     * Returns null if the stack is empty (underflow safety check).
     */
    public Product pop() {
    	if(isEmpty()) {
    		return null;
    	}
    	Product temp=top.data;
    	top=top.next;
    	size--;
    	return temp;
        
    	
    }

    /**
     * 3. Returns the top product without removing it.
     * Returns null if the stack is empty.
     */
    public Product peek() {
    	if(isEmpty()) {
    		return null;
    	}
    	return top.data;
    }

    /**
     * 4. Checks if the stack contains no items.
     */
    public boolean isEmpty() {
        return top == null;
    }

    /**
     * 5. Displays all products in the stack from top to bottom.
     */
    public void displayStack() {
    	if(isEmpty()) {
    		return ;
    	}
    	Node curr=top;
    	while(curr!=null) {
    		System.out.println(curr.data);
    		curr=curr.next;
    	}
    }

    // DRIVER PROGRAM
    public static void main(String[] args) {
        ProductReturnStack returns = new ProductReturnStack();
        System.out.println("Return stack empty initially? " + returns.isEmpty());

        System.out.println("\n--- PUSHING RETURNED PACKAGES ---");
        returns.push(new Product(401, "Bluetooth Speaker", "Audio", 4.2, 1999.0));
        returns.push(new Product(402, "Winter Jacket", "Apparel", 4.0, 3499.0));
        returns.push(new Product(403, "Running Shoes", "Footwear", 4.7, 4299.0));
        returns.displayStack();

        System.out.println("\n--- PEEK AT TOP ---");
        System.out.println("Next for inspection: " + returns.peek());

        System.out.println("\n--- INSPECTING PACKAGES (POP) ---");
        System.out.println("Inspected: " + returns.pop());
        System.out.println("Inspected: " + returns.pop());

        System.out.println("\n--- CURRENT STACK ---");
        returns.displayStack();

        System.out.println("\nInspected: " + returns.pop());
        System.out.println("Inspecting from empty stack: " + returns.pop());
    }
}
