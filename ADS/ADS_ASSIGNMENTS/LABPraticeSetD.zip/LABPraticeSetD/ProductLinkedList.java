package com.LABPraticeSetD;

/**
 * Custom Singly Linked List managing product records with positional insertion and threshold deletions.
 */
public class ProductLinkedList {

    private static class Node {
        Product data;
        Node next;

        Node(Product data) {
            this.data = data;
            this.next = null;
        }
    }

    private Node head;
    private int count;

    public ProductLinkedList() {
        this.head = null;
        this.count = 0;
    }

    /**
     * 1. Inserts a new product at the specified 0-indexed position.
     * Handles index 0 (new head), middle positions, and tail insertions.
     * Returns true if successful, or false if position is out of bounds (< 0 or > count).
     */
    public boolean insertAtPosition(Product prod, int pos) {
    	if(pos<0 || pos >count) {
    		return false;
    	}
    	Node newnode=new Node(prod);
    	if(pos==0) {
    		newnode.next=head;
    		head=newnode;
    		
    	}
    	else {
    		Node curr=head;
    		for(int i=0;i<pos-1;i++) {
    			curr=curr.next;
    		}
    		
    		newnode.next=curr.next;
    		curr.next=newnode;
    	}
    count++;
    return true;
     
    }

    /**
     * 2. Deletes all products whose price is strictly greater than or equal to minPrice.
     * Returns the total count of deleted products.
     */
    public int deleteByPriceThreshold(double minPrice) {
        int deletedcount=0;
        while(head!=null && head.data.getPrice()>=minPrice) {
        	head=head.next;
        	deletedcount++;
        	count--;
        }
        if(head==null) {
        	return deletedcount;
        }
        Node curr=head;
        while(curr.next!=null) {
        	if(curr.next.data.getPrice()>=minPrice) {
        		curr.next=curr.next.next;
        		deletedcount++;
        		count--;
        	}
        	else {
        		curr=curr.next;
        	}
        }
        

        return deletedcount;
    }

    /**
     * 3. Returns the current number of products in the list.
     */
    public int size() {
        return count;
    }

    /**
     * 4. Displays all products in the list from head to tail.
     */
    public void display() {
        if(head==null) {
        	System.out.println("empty");
        	return;
        }
        Node curr=head;
        while(curr!=null) {
        	System.out.println(curr.data);
        	curr=curr.next;
        }
    }

    // DRIVER PROGRAM
    public static void main(String[] args) {
        ProductLinkedList catalog = new ProductLinkedList();

        System.out.println("--- 1. POSITIONAL INSERTIONS ---");
        catalog.insertAtPosition(new Product(101, "Wireless Mouse", "Electronics", 4.3, 899.0), 0); // At head
        catalog.insertAtPosition(new Product(102, "Mechanical Keyboard", "Electronics", 4.8, 4500.0), 1); // At tail
        catalog.insertAtPosition(new Product(103, "USB-C Cable", "Accessories", 4.1, 499.0), 1); // In middle
        catalog.insertAtPosition(new Product(104, "Gaming Monitor", "Electronics", 4.7, 18500.0), 0); // New head
        catalog.insertAtPosition(new Product(105, "Noise Cancelling Headphones", "Audio", 4.6, 9999.0), 4); // New tail

        System.out.println("Invalid position (pos 99): " +
                catalog.insertAtPosition(new Product(106, "Webcam", "Electronics", 4.2, 2200.0), 99));

        System.out.println("\nCatalog (Size=" + catalog.size() + "):");
        catalog.display();

        System.out.println("\n--- 2. DELETING LUXURY ITEMS (Price >= Rs. 5000) ---");
        int deleted = catalog.deleteByPriceThreshold(5000.0);
        System.out.println("Total products deleted: " + deleted);

        System.out.println("\nCatalog after deletions (Size=" + catalog.size() + "):");
        catalog.display();
    }
}