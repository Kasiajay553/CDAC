package com.LABPraticeSetD;

/**
 * Class implementing optimized bubble sort for product inventory with multi-attribute criteria.
 */
public class ProductBubbleSort {

    /**
     * Sorts products in descending order of rating (highest rating first).
     * Ties are broken by price in ascending order (cheaper items first).
     * Incorporates an early-exit optimization flag if a pass performs zero swaps.
     */
    public static void bubbleSort(Product[] products) {
                int len=products.length;
                boolean swapped;
                for(int i=0;i<len-1;i++) {
                	swapped=false;
                	for(int j=0;j<len-1-i;j++) {
                		if((products[j].getRating()<products[j+1].getRating() )||(products[j].getRating()==products[j+1].getRating() && products[j].getPrice()>products[j+1].getPrice())) {
                			Product  temp=products[j];
                			products[j]=products[j+1];
                			products[j+1]=temp;
                			swapped=true;
                		}
                	}
                	if(!swapped) {
                		break;
                	}
                }
                
    }

    // DRIVER PROGRAM
    public static void main(String[] args) {
        Product[] inventory = {
            new Product(301, "Smart Watch", "Wearables", 4.5, 4999.0),
            new Product(302, "Fitness Tracker", "Wearables", 4.2, 1999.0),
            new Product(303, "Bluetooth Speaker", "Audio", 4.5, 2499.0), // Same rating as Smart Watch, cheaper!
            new Product(304, "Earbuds", "Audio", 4.8, 3999.0),
            new Product(305, "Power Bank", "Accessories", 4.2, 1499.0), // Same rating as Tracker, cheaper!
            new Product(306, "Laptop Stand", "Accessories", 4.5, 1299.0)  // Same rating, cheapest of the 4.5s!
        };

        System.out.println("--- BEFORE BUBBLE SORT ---");
        for (Product p : inventory) {
            System.out.println(p);
        }

        bubbleSort(inventory);

        System.out.println("\n--- AFTER OPTIMIZED BUBBLE SORT (Rating DESC, Price ASC) ---");
        for (Product p : inventory) {
            System.out.println(p);
        }
    }
}
