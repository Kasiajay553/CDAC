package com.LABPraticeSetC;

/**
 * Custom Singly Linked List maintaining patient records sorted in ascending order of age.
 */
public class PatientLinkedList {

    private static class Node {
        Patient data;
        Node next;

        Node(Patient data) {
            this.data = data;
            this.next = null;
        }
    }

    private Node head;

    public PatientLinkedList() {
        this.head = null;
    }

    /**
     * 1. Inserts a new patient in ascending order of age.
     * Handles empty list, insertion at the head, middle, and tail.
     */
    public void insertSortedByAge(Patient patient) {
    	Node newnode= new Node(patient);
    	if(head==null || patient.getAge()<head.data.getAge()) {
    		newnode.next=head;
    		head=newnode;
    		return;
    	}
    	Node curr=head;
    	while(curr.next!=null && curr.next.data.getAge()<=patient.getAge()) {
    		curr=curr.next;
    	}
    	newnode.next=curr.next;
    	curr.next=newnode;
       
    }

    /**
     * 2. Deletes a patient node by their unique ID.
     * Gracefully handles empty list, head deletion, middle/tail deletion, and non-existent IDs.
     */
    public boolean deleteById(int id) {
    	if(head==null) {
    		return false;
    	}
    	if(head.data.getId()==id){
    		head=head.next;
    		return true;
    	}
    	Node prev=head;
    	Node curr=head.next;
    	while(curr!=null) {
    		if(curr.data.getId()==id) {
    			prev.next=curr.next;
    			curr.next=null;
    			return true;
    		}
    		prev=curr;
    		curr=curr.next;
    	}
        return false;
    }

    /**
     * 3. Counts and returns the total number of patients suffering from the specified ailment.
     */
    public int countByAilment(String ailment) {
    	int count=0;
    	Node curr=head;
    	while(curr!=null){
    		if(curr.data.getAilment().equalsIgnoreCase(ailment)) {
    			count++;
    		}
    		curr=curr.next;
    	}
        
        return count;
    }

    /**
     * 4. Prints all patients in the linked list from head to tail.
     */
    public void display() {
        if(head==null) {
        	System.out.println("empty is list");
        }
        Node curr=head;
        while(curr!=null) {
        	System.out.println(curr.data);
        	curr=curr.next;
        }
    }

    // DRIVER PROGRAM
    public static void main(String[] args) {
        PatientLinkedList clinic = new PatientLinkedList();
        System.out.println("--- 1. INSERTING PATIENTS IN RANDOM ORDER ---");
        clinic.insertSortedByAge(new Patient(101, "Vinod", 45, "Cardiology"));
        clinic.insertSortedByAge(new Patient(102, "Shyam", 12, "Pediatrics"));
        clinic.insertSortedByAge(new Patient(103, "Ananya", 68, "Cardiology"));
        clinic.insertSortedByAge(new Patient(104, "Deepak", 29, "Orthopedics"));
        clinic.insertSortedByAge(new Patient(105, "Kavya", 5, "Pediatrics"));
        clinic.insertSortedByAge(new Patient(106, "Rahul", 82, "Geriatrics"));

        System.out.println("List state (automatically sorted by age):");
        clinic.display();

        System.out.println("\n--- 2. COUNT BY AILMENT ---");
        System.out.println("Cardiology Patients: " + clinic.countByAilment("Cardiology"));
        System.out.println("Pediatrics Patients: " + clinic.countByAilment("Pediatrics"));
        System.out.println("Neurology Patients: " + clinic.countByAilment("Neurology"));

        System.out.println("\n--- 3. DELETING PATIENTS ---");
        System.out.println("Deleting Head (Kavya, ID 105): " + clinic.deleteById(105));
        System.out.println("Deleting Middle (Vinod, ID 101): " + clinic.deleteById(101));
        System.out.println("Deleting Non-existent (999): " + clinic.deleteById(999));

        System.out.println("\n--- 4. FINAL LIST STATE ---");
        clinic.display();
    }
}