package com.LABPraticeSetC;



/**
 * Custom Circular Queue using a fixed-size array to manage outpatient triage registration.
 */
public class PatientCircularQueue {
    private Patient[] queue;
    private int front;
    private int rear;
    private int size;
    private int capacity;

    public PatientCircularQueue(int capacity) {
        this.capacity = capacity;
        this.queue = new Patient[capacity];
        this.front = 0;
        this.rear = -1;
        this.size = 0;
    }

    /**
     * 1. Enqueues a patient to the rear of the circular queue.
     * Returns true if successful, or false if the queue has reached capacity (overflow check).
     */
    public boolean enqueue(Patient p) {
    	if(isFull()) {
    		return false;
    	}
    	rear=(rear+1)%capacity;
    	queue[rear]=p;
    	size++;
       
        return true;
    }

    /**
     * 2. Dequeues and returns the patient from the front of the queue.
     * Returns null if the queue is empty (underflow check).
     */
    public Patient dequeue() {
    	if(isEmpty()) {
    		return null;
    	}
    	Patient dequeueElement=queue[front];
    	queue[front]=null;
    	front=(front+1)%capacity;
    	size--;
    	
    	return dequeueElement;
        
    }

    /**
     * 3. Checks if the circular queue has reached its capacity.
     */
    public boolean isFull() {
        return size == capacity;
    }

    /**
     * 4. Checks if the circular queue contains no elements.
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * 5. Displays all patients currently in the queue from Front to Rear in arrival order.
     */
    public void displayQueue() {
    	if(isEmpty()) {
    		System.out.println("the listis empty");
    	}
    	 int curr=front;
    	for(int i=0;i<size;i++) {
    		System.out.println(queue[curr]);
    		curr=(curr+1)%capacity;
    	}
       
    }

    // DRIVER PROGRAM
    public static void main(String[] args) {
        PatientCircularQueue triage = new PatientCircularQueue(4);
        System.out.println("Triage empty initially? " + triage.isEmpty());

        System.out.println("\n--- ADMITTING PATIENTS ---");
        triage.enqueue(new Patient(1, "Vinod", 45, "Fever"));
        triage.enqueue(new Patient(2, "Shyam", 30, "Fracture"));
        triage.enqueue(new Patient(3, "Ananya", 60, "Chest Pain"));
        triage.enqueue(new Patient(4, "Deepak", 18, "Allergy"));
        triage.displayQueue();

        System.out.println("Triage full? " + triage.isFull());
        System.out.println("Enqueueing 5th patient (overflow): " +
                triage.enqueue(new Patient(5, "Kavya", 25, "Migraine")));

        System.out.println("\n--- CALLING DOCTOR (DEQUEUE) ---");
        System.out.println("Treated: " + triage.dequeue());
        System.out.println("Treated: " + triage.dequeue());

        System.out.println("\n--- CIRCULAR WRAP-AROUND TEST ---");
        System.out.println("Enqueueing Kavya: " + triage.enqueue(new Patient(5, "Kavya", 25, "Migraine")));
        System.out.println("Enqueueing Rahul: " + triage.enqueue(new Patient(6, "Rahul", 50, "Hypertension")));
        triage.displayQueue();
    }
}
