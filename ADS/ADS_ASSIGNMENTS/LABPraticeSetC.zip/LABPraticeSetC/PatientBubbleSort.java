package com.LABPraticeSetC;

/**
 * Class implementing optimized bubble sort for patient records with multi-attribute criteria.
 */
public class PatientBubbleSort {

    /**
     * Sorts patients in ascending order of age.
     * Ties are broken by ID in ascending numerical order.
     * Incorporates an early-exit optimization flag if a pass performs zero swaps.
     */
    public static void bubbleSort(Patient[] patients) {
    	int  length=patients.length;
    	boolean swapped;
    	
    	for(int i=0;i<length-1;i++) {
    		swapped=false;
    		for(int j=0;j<length-1-i;j++) {
    			if(patients[j].getAge()>patients[j+1].getAge()) {
    				Patient temp=patients[j];
    				patients[j]=patients[j+1];
    				patients[j+1]=temp;
    				swapped=true;
    			}
    			else if(patients[j].getAge()==patients[j+1].getAge() && patients[j].getId()> patients[j+1].getId()) {
    				Patient temp=patients[j];
    				patients[j]=patients[j+1];
    				patients[j+1]=temp;
    				swapped=true;
    			}
    			
    		}
    		
    		
    		if(!swapped) {
    			break;
    		}
    	}
    	
        
    }

    // DRIVER PROGRAM
    public static void main(String[] args) {
        Patient[] ward = {
            new Patient(504, "Vinod", 42, "Orthopedics"),
            new Patient(501, "Shyam", 65, "Cardiology"),
            new Patient(502, "Ananya", 24, "General"),
            new Patient(505, "Deepak", 42, "Neurology"), // Same age as Vinod, ID higher
            new Patient(503, "Kavya", 18, "Pediatrics"),
            new Patient(500, "Rahul", 42, "Dermatology")  // Same age as Vinod/Deepak, ID lowest
        };

        System.out.println("--- BEFORE BUBBLE SORT ---");
        for (Patient p : ward) {
            System.out.println(p);
        }

        bubbleSort(ward);

        System.out.println("\n--- AFTER OPTIMIZED BUBBLE SORT (Age ASC, ID ASC) ---");
        for (Patient p : ward) {
            System.out.println(p);
        }
    }
}