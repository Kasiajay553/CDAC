package com.LABPraticeSetC;

/**
 * Patient model class representing individual patient health records.
 */
class Patient {
    private int id;
    private String name;
    private int age;
    private String ailment;

    public Patient(int id, String name, int age, String ailment) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.ailment = ailment;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getAilment() { return ailment; }

    @Override
    public String toString() {
        return String.format("Patient [ID=%d, Name %-10s, Age=%2d yrs, Ailment=%-12s]",
                id, name, age, ailment);
    }
}