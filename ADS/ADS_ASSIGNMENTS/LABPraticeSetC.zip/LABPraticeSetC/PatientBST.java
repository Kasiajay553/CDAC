package com.LABPraticeSetC;

/**
 * Custom Binary Search Tree (BST) storing patient records ordered by their ID.
 */
public class PatientBST {

    private static class BSTNode {
        Patient data;
        BSTNode left, right;

        BSTNode(Patient data) {
            this.data = data;
            this.left = this.right = null;
        }
    }

    private BSTNode root;

    public PatientBST() {
        this.root = null;
    }

    /**
     * 1. Public method to insert a new Patient into the BST ordered by ID.
     */
    public void insert(Patient p) {
       root=insertRec(root,p);
    }

    private BSTNode  insertRec(BSTNode curr,Patient p) {
    	if(curr==null) {
    		return new BSTNode(p);
    	}
    	if(p.getId()<curr.data.getId()) {
    		curr.left=insertRec(curr.left,p);
    	}
    	else if(p.getId()>curr.data.getId()) {
    		curr.right=insertRec(curr.right,p);
    	}
    	
    	return curr;
    }

    /**
     * 2. Inorder Traversal: Left -> Root -> Right (Displays patients sorted in ascending order of ID).
     */
    public void inorder() {
    	inoderRec(root);
        
    }

    private void inoderRec(BSTNode curr) {
    	
    	if(curr!=null) {
    		inoderRec(curr.left);
    		System.out.println(curr.data);
    		inoderRec(curr.right);
    	}
		
	}

	/**
     * 3. Postorder Traversal: Left -> Right -> Root.
     */
    public void postorder() {
       postorderRec(root);
    }

    
    private void postorderRec(BSTNode curr) {
    	
    	if(curr!=null) {
    		inoderRec(curr.left);
    		inoderRec(curr.right);
    		System.out.println(curr.data);
    	}
	}

	/**
     * 4. Finds and returns the patient with the minimum ID in the BST in O(h) time.
     * Returns null if the tree is empty.
     */
    public Patient findMin() {
    	BSTNode curr=root;
    	if(curr==null) {
    		System.out.println("empty");
    		return null;
    	}
    	while(curr.left!=null) {
    		curr=curr.left;
    	}
        return curr.data;
    }

    // DRIVER PROGRAM
    public static void main(String[] args) {
        PatientBST bst = new PatientBST();

        bst.insert(new Patient(40, "Vinod", 52, "Cardiology"));
        bst.insert(new Patient(20, "Shyam", 34, "Orthopedics"));
        bst.insert(new Patient(60, "Ananya", 29, "Neurology"));
        bst.insert(new Patient(10, "Deepak", 15, "Pediatrics"));
        bst.insert(new Patient(30, "Kavya", 68, "Geriatrics"));
        bst.insert(new Patient(50, "Rahul", 44, "General"));
        bst.insert(new Patient(70, "Pooja", 23, "Dermatology"));

        System.out.println("--- 1. INORDER TRAVERSAL (Sorted by ID) ---");
        bst.inorder();

        System.out.println("\n--- 2. POSTORDER TRAVERSAL (Left -> Right -> Root) ---");
        bst.postorder();

        System.out.println("\n--- 3. MINIMUM ID PATIENT ---");
        System.out.println("Min Patient: " + bst.findMin());
    }
}
